//
//  UserModel.m
//  Headlines
//
//  Created by mac12 on 16/9/21.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel

@end
