//
//  SubscriptViewController.h
//  Headlines
//
//  Created by mac50 on 16/9/19.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubscriptViewController : UIViewController

@end
