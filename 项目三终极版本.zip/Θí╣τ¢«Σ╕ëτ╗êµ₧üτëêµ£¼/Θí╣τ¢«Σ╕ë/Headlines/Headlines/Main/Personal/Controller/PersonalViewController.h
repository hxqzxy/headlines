//
//  PersonalViewController.h
//  Headlines
//
//  Created by mac12 on 16/9/18.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "BaseViewController.h"
#import "AppDelegate.h"

@interface PersonalViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UILabel *SizeLabel;

- (void)clearCache;
- (void)readCacheSize;
- (NSUInteger )getCacheData;

@end
