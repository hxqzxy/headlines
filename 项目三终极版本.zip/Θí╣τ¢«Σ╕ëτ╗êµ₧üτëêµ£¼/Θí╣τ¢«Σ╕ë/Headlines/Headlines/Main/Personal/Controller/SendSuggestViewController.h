//
//  SendSuggestViewController.h
//  Headlines
//
//  Created by mac12 on 16/9/21.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SendSuggestViewController : UIViewController

@end
