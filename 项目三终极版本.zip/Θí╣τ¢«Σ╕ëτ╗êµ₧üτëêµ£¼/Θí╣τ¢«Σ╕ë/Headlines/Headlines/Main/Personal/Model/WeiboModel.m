//
//  WeiboModel.m
//  Headlines
//
//  Created by mac12 on 16/9/21.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "WeiboModel.h"

@implementation WeiboModel

@end
