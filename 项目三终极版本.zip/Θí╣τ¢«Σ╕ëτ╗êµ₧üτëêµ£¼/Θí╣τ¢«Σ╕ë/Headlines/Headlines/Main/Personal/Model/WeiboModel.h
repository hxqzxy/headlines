//
//  WeiboModel.h
//  Headlines
//
//  Created by mac12 on 16/9/21.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserModel.h"

@class UserModel;

@interface WeiboModel : NSObject

@property (nonatomic,strong)UserModel *user;



@end
