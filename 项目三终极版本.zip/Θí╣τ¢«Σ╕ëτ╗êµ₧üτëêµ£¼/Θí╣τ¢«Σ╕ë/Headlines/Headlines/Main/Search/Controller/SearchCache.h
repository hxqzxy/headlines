//
//  SearchCache.h
//  Headlines
//
//  Created by mac12 on 16/9/22.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SearchCache : NSObject

+(void)SearchText :(NSString *)seaTxt;
+(void)removeAllArray;

@end
