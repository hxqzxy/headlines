//
//  SearchMessageViewController.h
//  Headlines
//
//  Created by mac12 on 16/9/23.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "BaseNavigationController.h"

@interface SearchMessageViewController: UIViewController

@property (strong, nonatomic)NSString *text;

@end
