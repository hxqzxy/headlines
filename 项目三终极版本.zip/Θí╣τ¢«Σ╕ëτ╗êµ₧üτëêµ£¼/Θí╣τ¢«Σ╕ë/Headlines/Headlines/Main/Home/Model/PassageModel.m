//
//  PassageModel.m
//  Headlines
//
//  Created by apple on 16/9/25.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "PassageModel.h"

@implementation PassageModel

@end
