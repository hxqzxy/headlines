//
//  RecommendModel.m
//  Headlines
//
//  Created by apple on 16/9/20.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "RecommendModel.h"

@implementation RecommendModel
+(NSDictionary *)modelCustomPropertyMapper{
    return @{@"recommendId" : @"id"};
}
@end
