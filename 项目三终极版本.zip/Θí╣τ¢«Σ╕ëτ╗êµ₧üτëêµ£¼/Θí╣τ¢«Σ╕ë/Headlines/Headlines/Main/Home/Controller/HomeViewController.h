//
//  HomeViewController.h
//  Headlines
//
//  Created by apple on 16/9/19.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "BaseViewController.h"

@interface HomeViewController : BaseViewController

@end
