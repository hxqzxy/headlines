//
//  RecommendView.h
//  Headlines
//
//  Created by apple on 16/9/20.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecommendView : UIView <UITableViewDelegate, UITableViewDataSource>

@end
